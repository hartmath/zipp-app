"use client";

import { AspectRatio as AspectRatioPrimitive } from "radix-ui";

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };
